# ============================================================================
# Colab 셀: ConvNeXt per-video 확률 export  (ConvNeXt_Artifact2-3.ipynb 뒤에 붙여 실행)
# ----------------------------------------------------------------------------
# 목적: best 체크포인트로 CelebDF(+DFD) 전 영상 추론 -> ensemble_eval.py 입력 CSV.
# 산출 컬럼: video_path, convnext_video_id, label, source, convnext_split, p1_convnext
#
# 전제(노트북에 이미 정의된 것 재사용):
#   test_model  : 로드된 ConvNeXtArtifactDetector (cell-19)
#   CFG, device, val_transform, DeepfakeDataset, clear_local_crops, extract_chunks
#   drive_dir = /content/drive/MyDrive/Deepfake_Preprocessed
#
# cell-24 버그 수정: extract_root 를 local_dir 로 통일(=CFG["path"]["base_dir"]).
#   (원본은 "/content"로 풀고 /content/processed_crops 를 뒤져 0개 수집됨)
# ============================================================================
import numpy as np
import pandas as pd
import torch
from pathlib import Path
from torch.utils.data import DataLoader

drive_dir = Path("/content/drive/MyDrive/Deepfake_Preprocessed")
local_dir = Path(CFG["path"]["base_dir"])          # ex) /content/processed_crops

# ConvNeXt 자신의 split/video_path/label 이 담긴 메타(identity_stratified 사용)
meta_csv = drive_dir / "dataset_metadata_identity_stratified_split.csv"
meta = pd.read_csv(meta_csv)
meta = deduplicate_metadata(meta) if "deduplicate_metadata" in dir() else meta
meta_by_vid = meta.set_index("video_id")

# 전 영상 대상(원하면 source로 필터). CelebDF만: meta = meta[meta.source=="CelebDF"]
all_tar_files = sorted(drive_dir.glob("dataset_chunk_*.tar"))
CHUNK = 8
tar_groups = [all_tar_files[i:i + CHUNK] for i in range(0, len(all_tar_files), CHUNK)]

records = []
test_model.eval()

for gi, group in enumerate(tar_groups, 1):
    print(f"[export {gi}/{len(tar_groups)}]", [p.name for p in group])
    clear_local_crops(local_dir)
    extract_chunks(group, extract_root=local_dir)          # <-- 버그 수정 지점

    available = {p.name for p in local_dir.iterdir() if p.is_dir()}
    sub = meta[meta["video_id"].isin(available)].reset_index(drop=True)
    print("  └ videos:", len(sub))
    if len(sub) == 0:
        continue

    ds = DeepfakeDataset(local_dir, sub, transform=val_transform,
                         max_frames=CFG["input"]["max_frame"])
    loader = DataLoader(ds, batch_size=CFG["training"]["batch_size"], shuffle=False,
                        num_workers=CFG["training"].get("num_workers", 2), pin_memory=True)

    # DeepfakeDataset은 (img, label, source)만 반환 -> video_id는 sub 순서로 매핑
    idx = 0
    with torch.no_grad():
        for imgs, labels, sources in loader:
            probs = torch.sigmoid(test_model(imgs.to(device))).cpu().numpy()
            for j in range(len(probs)):
                vid = sub.iloc[idx]["video_id"]; idx += 1
                row = meta_by_vid.loc[vid]
                records.append({
                    "video_path": row["video_path"],
                    "convnext_video_id": vid,
                    "label": int(row["label"]),
                    "source": row["source"],
                    "convnext_split": row["split"],
                    "p1_convnext": float(probs[j]),
                })

clear_local_crops(local_dir)

out = pd.DataFrame(records).drop_duplicates("convnext_video_id")
out_path = drive_dir / "convnext_probs_export.csv"
out.to_csv(out_path, index=False)
print("\n저장:", out_path, "| rows:", len(out))
print(out.groupby(["source", "convnext_split", "label"]).size())
# -> 이 CSV를 로컬 repo로 내려받아:
#    PYTHONNOUSERSITE=1 $PY scripts/ensemble_eval.py --convnext-csv convnext_probs_export.csv
