#!/usr/bin/env python
"""로컬에서 ConvNeXt 아티팩트 탐지기를 돌려 per-video 확률 CSV 생성.

two_stage_pipeline.Stage1Artifact 재사용(체크포인트 + 프레임 PNG -> fake 확률).
결과 CSV는 ensemble_eval.py가 그대로 소비.

frames 구조: <frames_base>/<convnext_video_id>/frames/*.png
targets CSV : video_id,k,label,split  (convnext_stage/cn_targets.csv)

사용:
  PYTHONNOUSERSITE=1 $PY scripts/run_convnext_local.py \
    --frames-base convnext_stage/frames --ckpt convnext_stage/epoch17.pt \
    --targets convnext_stage/cn_targets.csv --out convnext_stage/convnext_probs_local.csv
"""
import argparse
import csv
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(__file__))
from two_stage_pipeline import Stage1Artifact                # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--frames-base", default="convnext_stage/frames")
    ap.add_argument("--ckpt", default="convnext_stage/epoch17.pt")
    ap.add_argument("--targets", default="convnext_stage/cn_targets.csv")
    ap.add_argument("--out", default="convnext_stage/convnext_probs_local.csv")
    ap.add_argument("--source", default="CelebDF")
    args = ap.parse_args()

    targets = list(csv.DictReader(open(args.targets)))
    print(f"targets: {len(targets)}개")

    # 이 머신의 cuDNN이 CUDNN_STATUS_NOT_INITIALIZED로 깨져 있어 끔(GPU conv는 정상 동작).
    import torch
    torch.backends.cudnn.enabled = False

    stage1 = Stage1Artifact(args.ckpt, args.frames_base)

    rows, missing, done = [], 0, 0
    for t in targets:
        vid = t["video_id"]
        fdir = Path(args.frames_base) / vid / "frames"
        if not fdir.exists() or not any(fdir.glob("*.png")):
            missing += 1
            continue
        p1 = stage1.predict_proba(vid)
        rows.append({
            "video_path": "", "convnext_video_id": vid,
            "label": t["label"], "source": args.source,
            "convnext_split": t["split"], "p1_convnext": f"{p1:.6f}",
        })
        done += 1
        if done % 50 == 0:
            print(f"  {done}/{len(targets)} ...")

    with open(args.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["video_path", "convnext_video_id", "label",
                                          "source", "convnext_split", "p1_convnext"])
        w.writeheader()
        w.writerows(rows)
    print(f"\n저장: {args.out}  (추론 {done}개, 프레임없음 {missing}개)")


if __name__ == "__main__":
    main()
