#!/usr/bin/env python
"""2단 캐스케이드 딥페이크 탐지: 1차 아티팩트(ConvNeXt) -> 2차 AU(xgboost 30ch).

신뢰도 캐스케이드:
  1차(아티팩트)가 확신하면(|p1-0.5| >= margin) 그대로 판정,
  애매하면 2차(AU)를 돌려 결합 -> 최종 확률.

환경 무관 설계:
  - 경로/체크포인트는 인자로 주입. Colab(아티팩트 자산 위치)에서도, 로컬에서도 동작.
  - Stage1(ConvNeXt)은 timm + 체크포인트 + 프레임 PNG가 있어야 실행. 없으면 --verify가
    mock 1차 확률로 캐스케이드 로직 자체를 로컬에서 검증(2차 AU는 실제 실행).

입력 규약:
  Stage1: <frames_base>/<video_id>/frames/*.png   (영상당 프레임)
  Stage2: <data_dir>/<video_id>/features.npy       (30ch AU+pose+emotion)
  => 두 스테이지를 같은 영상에 돌리려면 video_id가 양쪽에 다 있어야 함(데이터 정렬 필요).

사용:
  # 로컬 검증(2차 실제 + 1차 mock): 캐스케이드 로직/지표 확인
  PYTHONNOUSERSITE=1 $PY scripts/two_stage_pipeline.py --verify
  # 실제 2단 평가(Colab/로컬, 둘 다 준비됐을 때)
  $PY scripts/two_stage_pipeline.py --eval --meta <csv> \
      --frames-base <dir> --artifact-ckpt <best.pt>
"""
import argparse
import hashlib
import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from au_detect.data.dataset import read_splits          # noqa: E402
from au_detect.features import stat_features, build_feature_matrix  # noqa: E402
from au_detect.metrics import roc_auc, f1_score          # noqa: E402


# ============================ Stage 1: 아티팩트(ConvNeXt) ============================
# (timm은 여기서만 필요 -> lazy import. ConvNeXt_Artifact2-3.ipynb의 모델을 그대로 옮김)

def _build_artifact_model(model_name, dropout, use_highpass):
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    import timm

    class HighPassPreprocess(nn.Module):
        def __init__(self, strength=0.15):
            super().__init__()
            k = torch.tensor([[0., -1., 0.], [-1., 4., -1.], [0., -1., 0.]])
            self.register_buffer("kernel", k.view(1, 1, 3, 3).repeat(3, 1, 1, 1))
            self.strength = strength

        def forward(self, x):
            return x + self.strength * F.conv2d(x, self.kernel, padding=1, groups=3)

    class ConvNeXtArtifactDetector(nn.Module):
        def __init__(self):
            super().__init__()
            self.pre = HighPassPreprocess(0.15) if use_highpass else nn.Identity()
            self.backbone = timm.create_model(model_name, pretrained=False,
                                              num_classes=0, global_pool="avg")
            d = self.backbone.num_features
            self.head = nn.Sequential(nn.LayerNorm(d), nn.Dropout(dropout), nn.Linear(d, 1))

        def forward(self, x):                       # x: (B, T, C, H, W)
            B, T, C, H, W = x.shape
            x = self.pre(x.view(B * T, C, H, W))
            feat = self.backbone(x).view(B, T, -1).mean(1)   # feature-level frame pooling
            return self.head(feat).squeeze(1)

    return ConvNeXtArtifactDetector()


class Stage1Artifact:
    """ConvNeXt 아티팩트 탐지기 래퍼. predict_proba(video_id) -> fake 확률."""

    def __init__(self, ckpt_path, frames_base, image_size=224, max_frames=64,
                 device=None, model_name="convnext_tiny", dropout=0.2, use_highpass=True):
        import torch
        from torchvision import transforms
        self.torch = torch
        self.frames_base = Path(frames_base)
        self.max_frames = max_frames
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")

        ckpt = torch.load(ckpt_path, map_location=self.device, weights_only=False)
        cfg = ckpt.get("cfg", {})
        mcfg = cfg.get("model", {})
        image_size = cfg.get("input", {}).get("image_size", image_size)
        self.model = _build_artifact_model(
            mcfg.get("model_name", model_name), mcfg.get("dropout", dropout),
            mcfg.get("use_highpass", use_highpass)).to(self.device)
        state = ckpt.get("model_state", ckpt.get("model_state_dict"))
        state = {k.replace("module.", ""): v for k, v in state.items()}
        self.model.load_state_dict(state, strict=True)
        self.model.eval()
        self.tf = transforms.Compose([
            transforms.ToPILImage(), transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
        print(f"[stage1] loaded {ckpt_path} (epoch={ckpt.get('epoch')})")

    def _load_frames(self, video_id):
        import cv2
        pngs = sorted((self.frames_base / video_id / "frames").glob("*.png"))[: self.max_frames]
        if not pngs:
            raise RuntimeError(f"프레임 없음: {video_id}")
        imgs = [cv2.cvtColor(cv2.imread(str(p)), cv2.COLOR_BGR2RGB) for p in pngs]
        while len(imgs) < self.max_frames:
            imgs.append(imgs[-1].copy())
        return self.torch.stack([self.tf(im) for im in imgs])   # (T,C,H,W)

    @property
    def available(self):
        return True

    def predict_proba(self, video_id):
        x = self._load_frames(video_id).unsqueeze(0).to(self.device)   # (1,T,C,H,W)
        with self.torch.no_grad():
            p = self.torch.sigmoid(self.model(x)).item()
        return float(p)

    def predict_proba_feat(self, video_id):
        """(p1, penultimate feature[D]) 반환. 라우터의 OOD 스코어용 backbone feature."""
        x = self._load_frames(video_id).unsqueeze(0).to(self.device)   # (1,T,C,H,W)
        with self.torch.no_grad():
            B, T, C, H, W = x.shape
            xr = self.model.pre(x.view(B * T, C, H, W))
            feat = self.model.backbone(xr).view(B, T, -1).mean(1)       # (1, D) frame-avg
            p = self.torch.sigmoid(self.model.head(feat).squeeze(1)).item()
        return float(p), feat.squeeze(0).cpu().numpy()


class MockStage1:
    """로컬 검증용 가짜 1차: video_id 해시로 재현가능한 '적당히 맞는' 확률 생성.
    (실제 ConvNeXt 없이 캐스케이드 로직·지표 계산을 검증하기 위한 것)"""

    def __init__(self, labels, skill=1.3, uncertain_frac=0.35):
        self.labels = labels          # video_id -> true label (신호가 있는 mock을 만들기 위해)
        self.skill = skill
        self.uncertain_frac = uncertain_frac
        self.available = True

    def predict_proba(self, video_id):
        seed = int(hashlib.md5(video_id.encode()).hexdigest()[:8], 16)
        rng = np.random.RandomState(seed)
        y = self.labels.get(video_id, rng.randint(0, 2))
        if rng.random() < self.uncertain_frac:      # 애매한 영상(0.5 근처) 일부러 생성
            return float(np.clip(0.5 + rng.normal(0, 0.05), 0.02, 0.98))
        logit = (y - 0.5) * 2 * self.skill + rng.normal(0, 0.8)
        return float(1 / (1 + np.exp(-logit)))


# ============================ Stage 2: AU (xgboost 30ch) ============================

class Stage2AU:
    """AU 30ch xgboost. 학습된 모델을 저장/로드하거나, 없으면 train split으로 학습."""

    def __init__(self, data_dir="data", splits_csv="outputs/v2/splits.csv",
                 feature_file="features.npy", n_channels=30,
                 model_path="outputs/v2/features/xgb_au.json"):
        import xgboost as xgb
        self.data_dir, self.feature_file, self.nc = data_dir, feature_file, n_channels
        self.clf = xgb.XGBClassifier()
        if Path(model_path).exists():
            self.clf.load_model(model_path)
            print(f"[stage2] loaded {model_path}")
        else:
            rows = read_splits(splits_csv)
            Xtr, ytr, _ = build_feature_matrix(rows, data_dir, "train", n_channels, feature_file)
            npos, nneg = (ytr == 1).sum(), (ytr == 0).sum()
            self.clf = xgb.XGBClassifier(n_estimators=300, max_depth=4, learning_rate=0.1,
                                         subsample=0.9, colsample_bytree=0.9, eval_metric="auc",
                                         scale_pos_weight=nneg / max(npos, 1), n_jobs=8, verbosity=0)
            self.clf.fit(Xtr, ytr)
            Path(model_path).parent.mkdir(parents=True, exist_ok=True)
            self.clf.save_model(model_path)
            print(f"[stage2] trained on {len(ytr)} videos -> saved {model_path}")

    def predict_proba(self, video_id):
        seq = np.load(f"{self.data_dir}/{video_id}/{self.feature_file}")
        x = stat_features(seq)[None, :]
        return float(self.clf.predict_proba(x)[0, 1])


# ============================ 캐스케이드 결합 ============================

class TwoStageCascade:
    def __init__(self, stage1, stage2, margin=0.15, threshold=0.5, combine="mean", w1=0.5):
        self.s1, self.s2 = stage1, stage2
        self.margin, self.threshold, self.combine, self.w1 = margin, threshold, combine, w1

    def predict(self, video_id):
        p1 = self.s1.predict_proba(video_id)
        if abs(p1 - 0.5) >= self.margin:                 # 1차가 확신 -> 통과
            final, p2, used2 = p1, None, False
        else:                                            # 애매 -> 2차 AU 재판정
            p2 = self.s2.predict_proba(video_id)
            if self.combine == "au":
                final = p2                               # AU가 결정
            elif self.combine == "weighted":
                final = self.w1 * p1 + (1 - self.w1) * p2
            else:
                final = 0.5 * (p1 + p2)                  # 평균
            used2 = True
        return {"video_id": video_id, "p1": p1, "p2": p2, "final": final,
                "used_stage2": used2, "pred": int(final >= self.threshold)}


# ============================ 평가 러너 ============================

def evaluate(cascade, items):
    """items: [(video_id, label, source)] -> 지표 dict."""
    P, Y, S, U, P1 = [], [], [], [], []
    for vid, y, src in items:
        r = cascade.predict(vid)
        P.append(r["final"]); Y.append(y); S.append(src)
        U.append(r["used_stage2"]); P1.append(r["p1"])
    P, Y, P1 = np.array(P), np.array(Y), np.array(P1)
    out = {"n": len(Y), "stage2_rate": float(np.mean(U)),
           "cascade_auc": roc_auc(Y, P), "stage1_only_auc": roc_auc(Y, P1),
           "f1": f1_score(Y, (P >= cascade.threshold).astype(int))}
    out["by_source"] = {}
    for s in sorted(set(S)):
        m = np.array(S) == s
        if len(np.unique(Y[m])) == 2:
            out["by_source"][s] = roc_auc(Y[m], P[m])
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--verify", action="store_true", help="2차 실제 + 1차 mock 로 로직 검증")
    ap.add_argument("--eval", action="store_true", help="실제 2단 평가")
    ap.add_argument("--meta", help="video_id,label,source 를 가진 csv (eval)")
    ap.add_argument("--frames-base", help="stage1 프레임 루트 (eval)")
    ap.add_argument("--artifact-ckpt", help="ConvNeXt 체크포인트 (eval)")
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--splits-csv", default="outputs/v2/splits.csv")
    ap.add_argument("--margin", type=float, default=0.15, help="1차 확신 밴드 (|p1-0.5|)")
    ap.add_argument("--threshold", type=float, default=0.5)
    ap.add_argument("--combine", default="mean", choices=["mean", "au", "weighted"])
    args = ap.parse_args()

    stage2 = Stage2AU(data_dir=args.data_dir, splits_csv=args.splits_csv)

    if args.verify:
        rows = [r for r in read_splits(args.splits_csv) if r["split"] == "test"]
        items = [(r["video_id"], int(r["label"]), r["source"]) for r in rows
                 if Path(f"{args.data_dir}/{r['video_id']}/features.npy").exists()]
        labels = {v: y for v, y, _ in items}
        stage1 = MockStage1(labels)
        casc = TwoStageCascade(stage1, stage2, args.margin, args.threshold, args.combine)
        res = evaluate(casc, items)
        print("\n=== VERIFY (2차 실제 AU + 1차 mock, v2 test split) ===")
        print(f"  n={res['n']}  stage2 재판정 비율={res['stage2_rate']:.1%}")
        print(f"  1차-only AUC(mock)={res['stage1_only_auc']:.3f}  ->  캐스케이드 AUC={res['cascade_auc']:.3f}")
        print(f"  by_source={ {k: round(v,3) for k,v in res['by_source'].items()} }")
        print("  (mock 1차라 절대값은 참고용; 캐스케이드 게이팅/결합/지표 계산이 동작함을 검증)")
        return

    if args.eval:
        import csv
        assert args.meta and args.frames_base and args.artifact_ckpt, \
            "--eval 에는 --meta --frames-base --artifact-ckpt 필요"
        stage1 = Stage1Artifact(args.artifact_ckpt, args.frames_base)
        casc = TwoStageCascade(stage1, stage2, args.margin, args.threshold, args.combine)
        items = [(r["video_id"], int(r["label"]), r.get("source", "?"))
                 for r in csv.DictReader(open(args.meta))]
        res = evaluate(casc, items)
        print(f"\n=== 2-STAGE EVAL (n={res['n']}) ===")
        print(f"  stage2 재판정 비율={res['stage2_rate']:.1%}")
        print(f"  1차-only AUC={res['stage1_only_auc']:.3f}  캐스케이드 AUC={res['cascade_auc']:.3f}  F1={res['f1']:.3f}")
        for s, a in res["by_source"].items():
            print(f"  [{s}] AUC={a:.3f}")
        return

    ap.print_help()


if __name__ == "__main__":
    main()
