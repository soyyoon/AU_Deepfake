#!/usr/bin/env python
"""WildDeepfake(미지 도메인, 두 모델 다 미학습) 제로샷 평가: ConvNeXt vs AU."""
import csv
import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(__file__))
from au_detect.metrics import roc_auc               # noqa: E402
from two_stage_pipeline import Stage2AU              # noqa: E402

cn = {r["convnext_video_id"]: float(r["p1_convnext"])
      for r in csv.DictReader(open("convnext_stage/convnext_probs_wdf.csv"))}
tgt = list(csv.DictReader(open("convnext_stage/wdf_targets.csv")))
stage2 = Stage2AU(data_dir="data", feature_file="features.npy", n_channels=30,
                  model_path="outputs/v2/features/xgb_au.json")

y, p1, p2 = [], [], []
miss = 0
for r in tgt:
    v = r["video_id"]
    if v not in cn or not Path(f"data/{v}/features.npy").exists():
        miss += 1
        continue
    y.append(int(r["label"])); p1.append(cn[v]); p2.append(stage2.predict_proba(v))
y, p1, p2 = np.array(y), np.array(p1), np.array(p2)

print(f"\nWildDeepfake n={len(y)} (real={int((y==0).sum())}, fake={int((y==1).sum())})  누락={miss}")
print("=" * 50)
print(f"  ConvNeXt-only AUC = {roc_auc(y, p1):.3f}")
print(f"  AU-only       AUC = {roc_auc(y, p2):.3f}")
print(f"  ConvNeXt p1: real={p1[y==0].mean():.3f} fake={p1[y==1].mean():.3f}")
print(f"  AU       p2: real={p2[y==0].mean():.3f} fake={p2[y==1].mean():.3f}")
np.savez("convnext_stage/wdf_probs.npz", y=y, p1=p1, p2=p2)
print("saved convnext_stage/wdf_probs.npz")
