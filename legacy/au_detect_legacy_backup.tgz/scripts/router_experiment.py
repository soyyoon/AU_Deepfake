#!/usr/bin/env python
"""OOD-aware 라우터 실험: 언제 ConvNeXt(아티팩트) vs AU를 믿을지 결정.

동기: CelebDF에선 ConvNeXt>>AU(0.92/0.59), FF++에선 반대(0.53/0.75). 정적 가중·
confidence 게이팅 모두 한쪽에서 붕괴. 여기선 ConvNeXt가 자기 학습분포(CelebDF/DFD)에서
벗어났는지를 penultimate feature 거리로 감지 -> in-dist면 ConvNeXt, OOD면 AU로 라우팅.

라벨 없이 도메인을 가를 수 있나? (CelebDF vs FF++ 분리 AUROC로 검증)
그리고 라우터가 오라클(도메인별 챔피언)의 macro-AUC에 근접하나?

데이터: CelebDF test(204)+val(215, in-dist 레퍼런스) frames=convnext_stage/frames,
        FF++ test(200) frames=convnext_stage/ffpp_frames. AU p2=Stage2AU(30ch).

  PYTHONNOUSERSITE=1 CUDA_VISIBLE_DEVICES=0 $PY scripts/router_experiment.py
"""
import csv
import os
import re
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(__file__))
from au_detect.data.dataset import read_splits          # noqa: E402
from au_detect.metrics import roc_auc                    # noqa: E402
from two_stage_pipeline import Stage1Artifact, Stage2AU  # noqa: E402


def au_canon(vid):
    m = re.match(r"celebdf_synthesis_(.+)$", vid)
    if m:
        return "fake:" + m.group(1)
    m = re.match(r"celebdf_real_(.+)$", vid)
    if m:
        return "real:" + m.group(1)
    return vid


# ----- 1) feature+p1+p2 수집 -----

def collect():
    import torch
    torch.backends.cudnn.enabled = False

    rows = read_splits("outputs/v2/splits.csv")
    stage2 = Stage2AU(data_dir="data", feature_file="features.npy", n_channels=30,
                      model_path="outputs/v2/features/xgb_au.json")

    # canonical -> cn_video_id (CelebDF frames는 cn id로 저장됨)
    cn_by_canon = {}
    for r in csv.DictReader(open("convnext_stage/cn_targets.csv")):
        cn_by_canon[r["k"]] = r["video_id"]

    s1_celeb = Stage1Artifact("convnext_stage/epoch17.pt", "convnext_stage/frames")
    s1_ffpp = Stage1Artifact("convnext_stage/epoch17.pt", "convnext_stage/ffpp_frames")

    data = {"celeb_test": [], "celeb_val": [], "ffpp_test": []}

    def add(bucket, au_vid, cn_frame_id, s1, label, domain):
        p1, feat = s1.predict_proba_feat(cn_frame_id)
        p2 = stage2.predict_proba(au_vid)
        data[bucket].append({"vid": au_vid, "y": int(label), "p1": p1, "p2": p2,
                             "feat": feat, "domain": domain})

    for r in rows:
        if r["source"] != "CelebDF":
            continue
        if r["split"] not in ("test", "val"):
            continue
        cn_id = cn_by_canon.get(au_canon(r["video_id"]))
        if cn_id is None:
            continue
        bucket = "celeb_test" if r["split"] == "test" else "celeb_val"
        try:
            add(bucket, r["video_id"], cn_id, s1_celeb, r["label"], "CelebDF")
        except Exception as e:
            print("skip", r["video_id"], str(e)[:60])

    ff = {r["video_id"]: r for r in csv.DictReader(open("convnext_stage/ffpp_cn_targets.csv"))}
    for vid, r in ff.items():
        try:
            add("ffpp_test", vid, vid, s1_ffpp, r["label"], "FFpp")
        except Exception as e:
            print("skip", vid, str(e)[:60])

    for k, v in data.items():
        print(f"  collected {k}: {len(v)}")
    return data


def arr(bucket, key):
    return np.array([r[key] for r in bucket])


def feats(bucket):
    return np.stack([r["feat"] for r in bucket])


# ----- 2) OOD 스코어 (PCA-50 공간 Mahalanobis, 레퍼런스=CelebDF val) -----

def build_ood(ref_feat, dim=50):
    mu0 = ref_feat.mean(0)
    sd0 = ref_feat.std(0) + 1e-6
    R = (ref_feat - mu0) / sd0
    U, S, Vt = np.linalg.svd(R, full_matrices=False)
    W = Vt[:dim].T                       # (D, dim) PCA basis
    P = R @ W                            # ref in PCA space
    mu = P.mean(0)
    cov = np.cov(P, rowvar=False) + 1e-3 * np.eye(P.shape[1])
    inv = np.linalg.inv(cov)

    def score(feat):
        X = ((feat - mu0) / sd0) @ W - mu
        return np.sqrt(np.einsum("ij,jk,ik->i", X, inv, X))
    return score


def percentile_cal(scores_pool):
    """pool 기준 순위->[0,1] 균등 스케일 변환기(모델별 캘리브레이션, 단조)."""
    order = np.argsort(np.argsort(scores_pool))
    ref_sorted = np.sort(scores_pool)

    def cal(x):
        return np.searchsorted(ref_sorted, x, side="right") / len(ref_sorted)
    return cal


CACHE = "convnext_stage/router_cache.npz"


def collect_cached():
    if Path(CACHE).exists():
        z = np.load(CACHE, allow_pickle=True)
        print(f"[cache] loaded {CACHE}")
        return {k: list(z[k]) for k in z.files}
    data = collect()
    np.savez(CACHE, **{k: np.array(v, dtype=object) for k, v in data.items()})
    print(f"[cache] saved {CACHE}")
    return data


def main():
    data = collect_cached()
    ct, cv, ft = data["celeb_test"], data["celeb_val"], data["ffpp_test"]

    ood = build_ood(feats(cv))
    z_ct, z_ft, z_cv = ood(feats(ct)), ood(feats(ft)), ood(feats(cv))

    # 도메인 분리력: OOD 스코어가 CelebDF-test(=in-dist) vs FF++(=OOD) 를 가르나
    dom_y = np.r_[np.zeros(len(ct)), np.ones(len(ft))]
    dom_s = np.r_[z_ct, z_ft]
    sep_auc = roc_auc(dom_y, dom_s)
    print("\n" + "=" * 60)
    print(f"OOD 도메인 분리 AUROC (CelebDF vs FF++) = {sep_auc:.3f}")
    print(f"  OOD score  CelebDF-val(ref) med={np.median(z_cv):.1f}  "
          f"CelebDF-test med={np.median(z_ct):.1f}  FF++ med={np.median(z_ft):.1f}")
    thr = np.quantile(z_cv, 0.95)        # 레퍼런스 95pct -> 이보다 멀면 OOD
    print(f"  임계값(ref 95pct)={thr:.1f}  -> CelebDF-test OOD판정률={np.mean(z_ct>thr):.1%}  "
          f"FF++ OOD판정률={np.mean(z_ft>thr):.1%}")

    # per-domain AUC 헬퍼
    def dom_auc(bucket, s):
        return roc_auc(arr(bucket, "y"), s)

    p1_ct, p2_ct = arr(ct, "p1"), arr(ct, "p2")
    p1_ft, p2_ft = arr(ft, "p1"), arr(ft, "p2")

    # 캘리브레이션(모델별, pool=CelebDF-test+FF++-test 순위)
    cal1 = percentile_cal(np.r_[p1_ct, p1_ft])
    cal2 = percentile_cal(np.r_[p2_ct, p2_ft])
    c1_ct, c1_ft = cal1(p1_ct), cal1(p1_ft)
    c2_ct, c2_ft = cal2(p2_ct), cal2(p2_ft)

    def macro(a_c, a_f):
        return 0.5 * (a_c + a_f)

    print("\n[per-domain AUC / macro]")
    def line(name, ac, af):
        print(f"  {name:26s} CelebDF={ac:.3f}  FF++={af:.3f}  macro={macro(ac,af):.3f}")

    line("ConvNeXt-only", dom_auc(ct, p1_ct), dom_auc(ft, p1_ft))
    line("AU-only", dom_auc(ct, p2_ct), dom_auc(ft, p2_ft))

    # 정적 가중 best (pool에서 w 하나 그리드)
    yb = np.r_[arr(ct, "y"), arr(ft, "y")]
    best_w, best = 0.5, -1
    for w in np.linspace(0, 1, 51):
        s = np.r_[w * c1_ct + (1 - w) * c2_ct, w * c1_ft + (1 - w) * c2_ft]
        a = 0.5 * (roc_auc(arr(ct, "y"), s[:len(ct)]) + roc_auc(arr(ft, "y"), s[len(ct):]))
        if a > best:
            best, best_w = a, w
    line(f"static weighted(w_cn={best_w:.2f})",
         roc_auc(arr(ct, "y"), best_w * c1_ct + (1 - best_w) * c2_ct),
         roc_auc(arr(ft, "y"), best_w * c1_ft + (1 - best_w) * c2_ft))

    line("oracle domain-router", dom_auc(ct, p1_ct), dom_auc(ft, p2_ft))

    # --- 하드 라우터: 임계값 스윕(이 OOD 신호의 상한) ---
    def hard_macro(z_c, z_f, t):
        s_c = np.where(z_c > t, c2_ct, c1_ct)
        s_f = np.where(z_f > t, c2_ft, c1_ft)
        return macro(roc_auc(arr(ct, "y"), s_c), roc_auc(arr(ft, "y"), s_f))

    def best_thr_router(name, z_c, z_f):
        cand = np.quantile(np.r_[z_c, z_f], np.linspace(0.02, 0.98, 49))
        bt = max(cand, key=lambda t: hard_macro(z_c, z_f, t))
        s_c = np.where(z_c > bt, c2_ct, c1_ct)
        s_f = np.where(z_f > bt, c2_ft, c1_ft)
        print(f"    (route->AU: CelebDF={np.mean(z_c>bt):.0%}, FF++={np.mean(z_f>bt):.0%})")
        line(name, roc_auc(arr(ct, "y"), s_c), roc_auc(arr(ft, "y"), s_f))

    best_thr_router("router Mahalanobis(best thr)", z_ct, z_ft)

    # --- kNN OOD (레퍼런스=CelebDF val, PCA-50, k=10 평균거리) ---
    def build_knn(ref_feat, dim=50, k=10):
        mu0, sd0 = ref_feat.mean(0), ref_feat.std(0) + 1e-6
        R = (ref_feat - mu0) / sd0
        _, _, Vt = np.linalg.svd(R, full_matrices=False)
        W = Vt[:dim].T
        P = R @ W

        def score(feat):
            X = ((feat - mu0) / sd0) @ W
            d = np.sqrt(((X[:, None, :] - P[None, :, :]) ** 2).sum(-1))
            return np.sort(d, 1)[:, :k].mean(1)
        return score
    knn = build_knn(feats(cv))
    zk_ct, zk_ft = knn(feats(ct)), knn(feats(ft))
    print(f"  kNN-OOD 도메인 분리 AUROC = {roc_auc(dom_y, np.r_[zk_ct, zk_ft]):.3f}")
    best_thr_router("router kNN(best thr)", zk_ct, zk_ft)

    # --- CV 메타학습 게이트: 신뢰도+OOD 특징으로 라벨 직접 예측(5-fold, pooled) ---
    def feat_vec(c1, c2, z):
        zc = (z - z.mean()) / (z.std() + 1e-6)
        return np.c_[c1, c2, np.abs(c1 - .5), np.abs(c2 - .5), c1 - c2, zc]
    X_ct = feat_vec(c1_ct, c2_ct, z_ct); X_ft = feat_vec(c1_ft, c2_ft, z_ft)
    X = np.r_[X_ct, X_ft]; Y = np.r_[arr(ct, "y"), arr(ft, "y")]
    dom = np.r_[np.zeros(len(ct)), np.ones(len(ft))]
    oof = np.zeros(len(Y))
    rng_idx = np.arange(len(Y))
    folds = [rng_idx[i::5] for i in range(5)]
    for f in range(5):
        te = folds[f]; tr = np.setdiff1d(rng_idx, te)
        mdl = logistic_fit_std(X[tr], Y[tr])
        oof[te] = logistic_pred_std(mdl, X[te])
    line("meta-gate (5-fold CV)",
         roc_auc(Y[dom == 0], oof[dom == 0]), roc_auc(Y[dom == 1], oof[dom == 1]))

    print("\n(oracle 0.857에 근접할수록 라우팅이 상보성을 실현. 단일최고=0.744)")


def logistic_fit_std(X, y, iters=3000, lr=0.2, l2=1e-2):
    mu, sd = X.mean(0), X.std(0) + 1e-8
    Xs = (X - mu) / sd
    w = np.zeros(Xs.shape[1]); b = 0.0
    for _ in range(iters):
        p = 1 / (1 + np.exp(-(Xs @ w + b)))
        g = p - y
        w -= lr * (Xs.T @ g / len(y) + l2 * w); b -= lr * g.mean()
    return {"w": w, "b": b, "mu": mu, "sd": sd}


def logistic_pred_std(m, X):
    Xs = (X - m["mu"]) / m["sd"]
    return 1 / (1 + np.exp(-(Xs @ m["w"] + m["b"])))


if __name__ == "__main__":
    main()
