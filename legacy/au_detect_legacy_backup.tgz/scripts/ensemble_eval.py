#!/usr/bin/env python
"""AU × ConvNeXt 공정 비교/앙상블 하니스 (확률 CSV 소비, GPU/timm/프레임 불필요).

핵심 아이디어:
  ConvNeXt per-video 확률을 Colab에서 CSV로 export받으면, 로컬은 확률 CSV +
  로컬 AU feature(data/<video_id>/features.npy)만으로 join·fusion·평가가 끝난다.

공통 평가셋:
  AU 파이프라인의 CelebDF test split(identity-disjoint 보장). ConvNeXt와의 join은
  정규화 id가 아니라 원본 파일 basename(예: id39_0000.mp4)으로 건다 -- CelebDF
  파일명은 전역 유일하므로 경로 prefix 차이에 강건.

공정성:
  공통셋 중 ConvNeXt가 자기 train에서 본 영상은 낙관적일 수 있음. export CSV에
  convnext_split이 있으면 heldout / trained 부분집합 AUC를 분리 보고한다.

Fusion:
  mean(0.5/0.5), weighted(val로 가중치 grid), LR stacker(val로 학습, numpy),
  cascade gating(|p1-0.5|>=margin이면 p1, 아니면 평균) -- two_stage_pipeline과 동일 로직.

ConvNeXt CSV 규약(최소): video_path, label, p1_convnext(또는 prob/p1)
  선택: source, convnext_split(train/val/test), convnext_video_id

사용:
  # 실제 평가 (Colab export CSV로)
  PYTHONNOUSERSITE=1 $PY scripts/ensemble_eval.py --convnext-csv convnext_probs_celebdf.csv
  # Colab 없이 스모크 테스트용 mock CSV 생성 후 평가
  PYTHONNOUSERSITE=1 $PY scripts/ensemble_eval.py --make-mock /tmp/mock_convnext.csv
  PYTHONNOUSERSITE=1 $PY scripts/ensemble_eval.py --convnext-csv /tmp/mock_convnext.csv
"""
import argparse
import csv
import hashlib
import os
import re
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from au_detect.data.dataset import read_splits              # noqa: E402
from au_detect.metrics import roc_auc, f1_score             # noqa: E402

# Stage2AU(재사용): AU 30ch xgboost per-video 확률
sys.path.insert(0, os.path.dirname(__file__))
from two_stage_pipeline import Stage2AU                      # noqa: E402


# ------------------------------ join key ------------------------------
# 두 파이프라인은 CelebDF 원본 식별자로 join한다. video_path 컬럼은 무의미(폴더 경로)하고,
# 원본 이름은 video_id 안에 인코딩돼 있다:
#   AU  real: celebdf_real_00000 / celebdf_real_id0_0000
#       fake: celebdf_synthesis_id0_id17_0000
#   CN  real: celebdf_00000_real / celebdf_id0_0000_real
#       fake: celebdf_id0_id17_0000_fake
# -> canonical key "real:00000", "fake:id0_id17_0000" 로 정규화(검증: 890 fake/300 yt-real 완전매칭).

def au_canon(video_id):
    m = re.match(r"celebdf_synthesis_(.+)$", video_id)
    if m:
        return "fake:" + m.group(1)
    m = re.match(r"celebdf_real_(.+)$", video_id)
    if m:
        return "real:" + m.group(1)
    return video_id            # 그 외(FFpp/DFDC 등)는 원본 id로 identity join


def cn_canon(video_id):
    m = re.match(r"celebdf_(.+)_fake$", video_id)
    if m:
        return "fake:" + m.group(1)
    m = re.match(r"celebdf_(.+)_real$", video_id)
    if m:
        return "real:" + m.group(1)
    return video_id            # FFpp 등은 ConvNeXt CSV의 convnext_video_id = AU video_id


def load_convnext_csv(path):
    """canonical key -> {p1, label, split, source}. convnext_video_id로 키 생성."""
    rows = list(csv.DictReader(open(path)))
    if not rows:
        raise RuntimeError(f"빈 CSV: {path}")
    cols = rows[0].keys()
    p1_col = next((c for c in ("p1_convnext", "prob", "p1", "convnext_prob") if c in cols), None)
    if p1_col is None:
        raise RuntimeError(f"확률 컬럼 없음(p1_convnext/prob/p1 중 하나 필요). 있는 컬럼: {list(cols)}")
    if "convnext_video_id" not in cols:
        raise RuntimeError(f"convnext_video_id 컬럼 필요. 있는 컬럼: {list(cols)}")
    out = {}
    dup = skip = 0
    for r in rows:
        k = cn_canon(r["convnext_video_id"])
        if k is None:
            skip += 1
            continue
        if k in out:
            dup += 1
        out[k] = {
            "p1": float(r[p1_col]),
            "label": int(r["label"]) if r.get("label", "") != "" else None,
            "split": r.get("convnext_split", "") or None,
            "source": r.get("source", "") or None,
        }
    if dup:
        print(f"[warn] ConvNeXt CSV canonical-key 중복 {dup}건(마지막 유지)")
    if skip:
        print(f"[warn] canonical-key 파싱 실패 {skip}건(CelebDF 아님 등, 무시)")
    return out


def logistic_fit(X, y, iters=2000, lr=0.1, l2=1e-3):
    """작은 numpy 로지스틱 회귀(스태커). X:[n,d], y:[n] -> w,b."""
    X = np.asarray(X, np.float64)
    y = np.asarray(y, np.float64)
    # 표준화(수렴 안정)
    mu, sd = X.mean(0), X.std(0)
    sd[sd < 1e-8] = 1e-8
    Xs = (X - mu) / sd
    n, d = Xs.shape
    w = np.zeros(d)
    b = 0.0
    for _ in range(iters):
        z = Xs @ w + b
        p = 1.0 / (1.0 + np.exp(-z))
        g = p - y
        gw = Xs.T @ g / n + l2 * w
        gb = g.mean()
        w -= lr * gw
        b -= lr * gb
    return {"w": w, "b": b, "mu": mu, "sd": sd}


def logistic_predict(model, X):
    Xs = (np.asarray(X, np.float64) - model["mu"]) / model["sd"]
    z = Xs @ model["w"] + model["b"]
    return 1.0 / (1.0 + np.exp(-z))


def best_weight(y, p1, p2, grid=None):
    """val에서 w*p1+(1-w)*p2 의 AUC 최대화하는 w."""
    grid = grid if grid is not None else np.linspace(0, 1, 51)
    best_w, best_a = 0.5, -1.0
    for w in grid:
        a = roc_auc(y, w * p1 + (1 - w) * p2)
        if a > best_a:
            best_a, best_w = a, float(w)
    return best_w, best_a


def cascade_fuse(p1, p2, margin=0.15):
    """|p1-0.5|>=margin이면 p1, 아니면 0.5*(p1+p2). two_stage_pipeline과 동일."""
    p1, p2 = np.asarray(p1), np.asarray(p2)
    confident = np.abs(p1 - 0.5) >= margin
    return np.where(confident, p1, 0.5 * (p1 + p2)), confident


# ------------------------------ 공통셋 구성 ------------------------------

def build_paired(cn, split_rows, source, data_dir, stage2, split_name):
    """지정 split의 공통셋(y, p1, p2, cn_split, video_id) 구성. 매칭/미매칭 로그."""
    au_rows = [r for r in split_rows
               if r["source"] == source and r["split"] == split_name]
    matched, missing_cn, missing_feat = [], 0, 0
    for r in au_rows:
        key = au_canon(r["video_id"])
        if key is None or key not in cn:
            missing_cn += 1
            continue
        feat = Path(data_dir) / r["video_id"] / stage2.feature_file
        if not feat.exists():
            missing_feat += 1
            continue
        matched.append((r, cn[key]))

    y, p1, p2, cn_split, vids = [], [], [], [], []
    for r, c in matched:
        p2v = stage2.predict_proba(r["video_id"])
        y.append(int(r["label"]))
        p1.append(c["p1"])
        p2.append(p2v)
        cn_split.append(c["split"])
        vids.append(r["video_id"])
    print(f"  [{split_name}] AU {source} 후보={len(au_rows)}  매칭={len(matched)}  "
          f"ConvNeXt미발견={missing_cn}  feature없음={missing_feat}")
    return {
        "y": np.array(y), "p1": np.array(p1, float), "p2": np.array(p2, float),
        "cn_split": np.array([s or "" for s in cn_split]), "vids": vids,
    }


# ------------------------------ 리포트 ------------------------------

def auc_or_na(y, s):
    return roc_auc(y, s) if len(np.unique(y)) == 2 and len(y) > 0 else float("nan")


def report(test, val, margin):
    y, p1, p2 = test["y"], test["p1"], test["p2"]
    print("\n" + "=" * 64)
    print(f"공통 테스트셋 n={len(y)}  (fake={int((y==1).sum())}, real={int((y==0).sum())})")
    print("=" * 64)

    # --- 단일 모델 (공정) ---
    a_cn, a_au = auc_or_na(y, p1), auc_or_na(y, p2)
    print("\n[단일 모델]  (같은 공통셋, 같은 잣대)")
    print(f"  ConvNeXt-only AUC = {a_cn:.4f}")
    print(f"  AU-only       AUC = {a_au:.4f}")

    # --- 누수 분리 (convnext_split 있을 때) ---
    if (test["cn_split"] != "").any():
        held = test["cn_split"] != "train"
        for name, mask in (("heldout(ConvNeXt val/test)", held), ("trained(ConvNeXt train)", ~held)):
            if mask.sum() > 0:
                print(f"  · {name}: n={int(mask.sum())}  "
                      f"ConvNeXt={auc_or_na(y[mask], p1[mask]):.4f}  AU={auc_or_na(y[mask], p2[mask]):.4f}")
        print("  (진짜 공정 비교치 = heldout 부분집합)")
    else:
        print("  [warn] convnext_split 없음 -> 누수 분리 불가. export에 컬럼 추가 권장.")

    # --- Fusion ---
    print("\n[Fusion]  (단일 최고 대비)")
    base = max(a_cn, a_au)
    fusions = {}

    fusions["mean(0.5/0.5)"] = 0.5 * (p1 + p2)

    if len(val["y"]) > 0 and len(np.unique(val["y"])) == 2:
        w, wv = best_weight(val["y"], val["p1"], val["p2"])
        fusions[f"weighted(w_cn={w:.2f})"] = w * p1 + (1 - w) * p2
        lr = logistic_fit(np.stack([val["p1"], val["p2"]], 1), val["y"])
        fusions["LR-stacker"] = logistic_predict(lr, np.stack([p1, p2], 1))
        print(f"  (가중치/스태커는 val n={len(val['y'])}로 학습 -> test 적용, 누수 없음)")
    else:
        print("  [warn] val 공통셋 부족 -> weighted/LR 생략(mean/cascade만).")

    casc, conf = cascade_fuse(p1, p2, margin)
    fusions[f"cascade(margin={margin})"] = casc
    stage2_rate = float((~conf).mean())

    for name, s in fusions.items():
        a = auc_or_na(y, s)
        delta = a - base
        mark = "▲" if delta > 1e-4 else ("▼" if delta < -1e-4 else "=")
        print(f"  {name:22s} AUC={a:.4f}  vs 단일최고({base:.4f})  {mark}{delta:+.4f}")
    print(f"  (cascade에서 AU 재판정 비율={stage2_rate:.1%})")

    # --- 상보성 ---
    print("\n[상보성 분석]")
    if len(y) > 1:
        corr = float(np.corrcoef(p1, p2)[0, 1])
        pred_cn = (p1 >= 0.5).astype(int)
        pred_au = (p2 >= 0.5).astype(int)
        cn_wrong_au_right = int(((pred_cn != y) & (pred_au == y)).sum())
        au_wrong_cn_right = int(((pred_au != y) & (pred_cn == y)).sum())
        disagree = float((pred_cn != pred_au).mean())
        print(f"  corr(p1,p2) = {corr:+.3f}   불일치율(@0.5) = {disagree:.1%}")
        print(f"  ConvNeXt틀림 & AU맞음 = {cn_wrong_au_right}   AU틀림 & ConvNeXt맞음 = {au_wrong_cn_right}")
        print("  (앙상블 가치는 fusion AUC가 단일최고를 유의미하게 넘고, 상보 케이스가 많을 때)")


# ------------------------------ mock 생성 ------------------------------

def canon_to_cn(key):
    """canonical key -> CN 스타일 video_id (mock용). real:00000 -> celebdf_00000_real."""
    kind, name = key.split(":", 1)
    return f"celebdf_{name}_{'fake' if kind == 'fake' else 'real'}"


def make_mock(out_path, split_rows, source, skill=1.4):
    """Colab 없이 스모크 테스트용 mock ConvNeXt CSV. label 상관 신호 + 재현가능."""
    rows = [r for r in split_rows if r["source"] == source
            and r["split"] in ("val", "test") and au_canon(r["video_id"])]
    with open(out_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["video_path", "convnext_video_id", "label", "source", "convnext_split", "p1_convnext"])
        for r in rows:
            key = au_canon(r["video_id"])
            seed = int(hashlib.md5(key.encode()).hexdigest()[:8], 16)
            rng = np.random.RandomState(seed)
            y = int(r["label"])
            logit = (y - 0.5) * 2 * skill + rng.normal(0, 0.9)
            p1 = float(1 / (1 + np.exp(-logit)))
            cn_split = "test" if rng.random() < 0.7 else "train"  # 일부러 누수 섞기
            w.writerow(["", canon_to_cn(key), y, source, cn_split, f"{p1:.6f}"])
    print(f"mock ConvNeXt CSV 저장: {out_path} ({len(rows)} rows)")


# ------------------------------ main ------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--convnext-csv", help="ConvNeXt per-video 확률 CSV")
    ap.add_argument("--make-mock", metavar="OUT", help="스모크용 mock CSV를 생성하고 종료")
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--splits-csv", default="outputs/v2/splits.csv")
    ap.add_argument("--au-model", default="outputs/v2/features/xgb_au.json")
    ap.add_argument("--source", default="CelebDF", help="공통 평가 소스")
    ap.add_argument("--margin", type=float, default=0.15)
    args = ap.parse_args()

    split_rows = read_splits(args.splits_csv)

    if args.make_mock:
        make_mock(args.make_mock, split_rows, args.source)
        return

    assert args.convnext_csv, "--convnext-csv 또는 --make-mock 필요"
    cn = load_convnext_csv(args.convnext_csv)
    print(f"ConvNeXt CSV: {len(cn)}개 canonical-key 로드")

    stage2 = Stage2AU(data_dir=args.data_dir, splits_csv=args.splits_csv,
                      feature_file="features.npy", n_channels=30, model_path=args.au_model)

    print("\n공통셋 join 중...")
    test = build_paired(cn, split_rows, args.source, args.data_dir, stage2, "test")
    val = build_paired(cn, split_rows, args.source, args.data_dir, stage2, "val")

    if len(test["y"]) == 0:
        print("\n[에러] 공통 테스트셋이 비었습니다. video_path basename 매칭을 확인하세요.")
        return

    report(test, val, args.margin)


if __name__ == "__main__":
    main()
