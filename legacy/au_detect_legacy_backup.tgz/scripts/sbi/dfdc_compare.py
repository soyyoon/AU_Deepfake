#!/usr/bin/env python
"""DFDC(완전 미지 도메인) 네 모델 비교: SBI / ConvNeXt / AU / 앙상블.

sbi env(cudnn 정상)에서 SBI+ConvNeXt(timm) 추론, Stage2AU(xgboost)로 AU. 비디오-레벨.
  PYTHONNOUSERSITE=1 CUDA_VISIBLE_DEVICES=0 conda run -n sbi python scripts/sbi/dfdc_compare.py
"""
import csv
import os
import sys
from pathlib import Path

import numpy as np
import cv2
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))
from dataset import MEAN, STD                       # noqa: E402
from two_stage_pipeline import Stage1Artifact, Stage2AU  # noqa: E402


def roc_auc(y, s):
    y = np.asarray(y); s = np.asarray(s)
    p, n = (y == 1).sum(), (y == 0).sum()
    if p == 0 or n == 0:
        return float("nan")
    r = np.argsort(np.argsort(s)) + 1
    return float((r[y == 1].sum() - p * (p + 1) / 2) / (p * n))


def rank01(s):
    r = np.argsort(np.argsort(s))
    return r / max(len(s) - 1, 1)


CROPS = "dfdc_stage/crops"
AU_DATA = "dfdc_stage/au_data"
dev = "cuda" if torch.cuda.is_available() else "cpu"

import timm
# --- SBI ---
ck = torch.load("outputs/sbi/best.pt", map_location=dev, weights_only=False)
size = ck["cfg"].get("size", 256)
sbi = timm.create_model(ck["cfg"]["model"], pretrained=False, num_classes=1).to(dev)
sbi.load_state_dict(ck["model"]); sbi.eval()

# --- ConvNeXt (frames avg 내부처리) ---
cn = Stage1Artifact("convnext_stage/epoch17.pt", CROPS)

# --- AU ---
au = Stage2AU(data_dir=AU_DATA, feature_file="features.npy", n_channels=30,
              model_path="outputs/v2/features/xgb_au.json")


def sbi_score(vid):
    d = Path(CROPS) / vid / "frames"
    pngs = sorted(d.glob("*.png"))[:32]
    batch = []
    for p in pngs:
        im = cv2.imread(str(p))
        if im is None:
            continue
        im = cv2.cvtColor(im, cv2.COLOR_BGR2RGB)
        im = cv2.resize(im, (size, size)).astype(np.float32) / 255.0
        batch.append(((im - MEAN) / STD).transpose(2, 0, 1))
    if not batch:
        return None
    x = torch.from_numpy(np.stack(batch)).to(dev)
    with torch.no_grad(), torch.amp.autocast("cuda"):
        return float(torch.sigmoid(sbi(x).squeeze(1)).float().mean().cpu())


rows = list(csv.DictReader(open("dfdc_stage/targets.csv")))
Y, S, C, A = [], [], [], []
miss = 0
for r in rows:
    vid = r["video_id"]
    if not (Path(CROPS) / vid / "frames").exists() or not (Path(AU_DATA) / vid / "features.npy").exists():
        miss += 1
        continue
    ss = sbi_score(vid)
    if ss is None:
        miss += 1
        continue
    try:
        cc = cn.predict_proba(vid)
        aa = au.predict_proba(vid)
    except Exception:
        miss += 1
        continue
    Y.append(int(r["label"])); S.append(ss); C.append(cc); A.append(aa)

Y, S, C, A = map(np.array, (Y, S, C, A))
print("\n" + "=" * 56)
print(f"DFDC (완전 미지 도메인) n={len(Y)} (real={int((Y==0).sum())}, fake={int((Y==1).sum())}) 누락={miss}")
print("=" * 56)
print(f"  SBI       AUC = {roc_auc(Y, S):.4f}")
print(f"  ConvNeXt  AUC = {roc_auc(Y, C):.4f}")
print(f"  AU        AUC = {roc_auc(Y, A):.4f}")
ens3 = (rank01(S) + rank01(C) + rank01(A)) / 3
ens_sc = (rank01(S) + rank01(C)) / 2
print(f"  앙상블(SBI+CN+AU, rank평균) AUC = {roc_auc(Y, ens3):.4f}")
print(f"  앙상블(SBI+CN)             AUC = {roc_auc(Y, ens_sc):.4f}")
np.savez("dfdc_stage/dfdc_probs.npz", y=Y, sbi=S, cn=C, au=A)
print("saved dfdc_stage/dfdc_probs.npz")
