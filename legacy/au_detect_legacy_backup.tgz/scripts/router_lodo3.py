#!/usr/bin/env python
"""3-도메인 leave-one-domain-out: 라우터가 진짜 미지 도메인(WildDeepfake 포함)에 일반화되나?

도메인: CelebDF, FF++ (router_cache.npz) + WildDeepfake (wdf_probs.npz).
각 도메인을 hold-out -> 나머지 2개로 메타게이트 학습 -> hold-out에서 평가.
특징=[c1,c2,|c1-.5|,|c2-.5|,c1-c2] (신뢰도+불일치; OOD 제외=단순화). 캘리브레이션은 학습풀만.
"""
import numpy as np

def roc_auc(y, s):
    y = np.asarray(y); s = np.asarray(s)
    p, n = (y == 1).sum(), (y == 0).sum()
    if p == 0 or n == 0:
        return float("nan")
    r = np.argsort(np.argsort(s)) + 1
    return float((r[y == 1].sum() - p * (p + 1) / 2) / (p * n))

# 도메인 로드
z = np.load("convnext_stage/router_cache.npz", allow_pickle=True)
D = {k: list(z[k]) for k in z.files}
def pk(b, k): return np.array([r[k] for r in b])
dom = {
    "CelebDF": (pk(D["celeb_test"], "p1"), pk(D["celeb_test"], "p2"), pk(D["celeb_test"], "y")),
    "FF++":    (pk(D["ffpp_test"], "p1"),  pk(D["ffpp_test"], "p2"),  pk(D["ffpp_test"], "y")),
}
w = np.load("convnext_stage/wdf_probs.npz")
dom["WildDeepfake"] = (w["p1"], w["p2"], w["y"])

def pcal(train):
    rs = np.sort(train)
    return lambda x: np.searchsorted(rs, x, side="right") / len(rs)

def fvec(c1, c2):
    return np.c_[c1, c2, np.abs(c1 - .5), np.abs(c2 - .5), c1 - c2]

def logfit(X, y, it=3000, lr=0.2, l2=1e-2):
    mu, sd = X.mean(0), X.std(0) + 1e-8
    Xs = (X - mu) / sd; wt = np.zeros(Xs.shape[1]); b = 0.
    for _ in range(it):
        p = 1 / (1 + np.exp(-(Xs @ wt + b))); g = p - y
        wt -= lr * (Xs.T @ g / len(y) + l2 * wt); b -= lr * g.mean()
    return dict(w=wt, b=b, mu=mu, sd=sd)

def logpred(m, X):
    return 1 / (1 + np.exp(-(((X - m["mu"]) / m["sd"]) @ m["w"] + m["b"])))

names = list(dom)
print("=" * 66)
print("도메인별 단일 모델 (제로샷/보유):")
for d in names:
    p1, p2, y = dom[d]
    print(f"  {d:14s} ConvNeXt={roc_auc(y,p1):.3f}  AU={roc_auc(y,p2):.3f}  (n={len(y)}, fake={int(y.sum())})")

print("\n3-도메인 LODO (2개 학습 -> 안 본 1개 평가):")
g_list, o_list = [], []
for held in names:
    tr = [d for d in names if d != held]
    p1tr = np.concatenate([dom[d][0] for d in tr]); p2tr = np.concatenate([dom[d][1] for d in tr])
    ytr = np.concatenate([dom[d][2] for d in tr])
    c1 = pcal(p1tr); c2 = pcal(p2tr)
    gate = logfit(fvec(c1(p1tr), c2(p2tr)), ytr)
    p1e, p2e, ye = dom[held]
    pred = logpred(gate, fvec(c1(p1e), c2(p2e)))
    g = roc_auc(ye, pred); o = max(roc_auc(ye, p1e), roc_auc(ye, p2e))
    g_list.append(g); o_list.append(o)
    print(f"  학습[{'+'.join(tr)}] -> {held}(미지): "
          f"게이트={g:.3f}  (그 도메인 챔피언={o:.3f}, ConvNeXt={roc_auc(ye,p1e):.3f}/AU={roc_auc(ye,p2e):.3f})")

print("\n" + "=" * 66)
print(f"미지도메인 게이트 macro={np.mean(g_list):.3f}  vs  오라클 macro={np.mean(o_list):.3f}")
print("→ 게이트≈오라클이면 라우팅 일반화 성공, 못 미치면 야생 부적합")
