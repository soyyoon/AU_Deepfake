#!/usr/bin/env python
"""이미지 시퀀스(얼굴크롭 폴더) -> pyfeat 30ch feature.npy (AU 모델 입력).

WildDeepfake 등 '영상' 대신 '프레임 시퀀스 폴더'로 배포된 데이터용. 각 video_id의
frames/*.png 를 pyfeat detect_image로 처리 -> per_frame_matrix(30ch) -> 64로 resample
-> data/<video_id>/features.npy. extract_features.py의 헬퍼 재사용. 샤딩/resumable.

  PY=/home/soyoon/anaconda3/envs/pyfeat/bin/python
  PYTHONNOUSERSITE=1 CUDA_VISIBLE_DEVICES=0 $PY scripts/extract_features_seq.py \
      --frames-base convnext_stage/wdf_frames --targets convnext_stage/wdf_targets.csv \
      --source WildDeepfake [--shard i --nshard N] [--limit K]
"""
import argparse
import csv
import json
import os
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from extract_features import per_frame_matrix, resample_time   # noqa: E402

GROUPS = ["aus", "poses", "emotions"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--frames-base", required=True)
    ap.add_argument("--targets", required=True)
    ap.add_argument("--out", default="data")
    ap.add_argument("--source", default="WildDeepfake")
    ap.add_argument("--seq-len", type=int, default=64)
    ap.add_argument("--max-frames", type=int, default=64, help="시퀀스당 최대 프레임(속도)")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--shard", type=int, default=0)
    ap.add_argument("--nshard", type=int, default=1)
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    rows = list(csv.DictReader(open(args.targets)))
    if args.nshard > 1:
        rows = [r for i, r in enumerate(rows) if i % args.nshard == args.shard]
    if args.limit:
        rows = rows[: args.limit]

    from feat import Detector
    detector = Detector(device=args.device)
    print(f"[seq-feat] {len(rows)} seqs | Detector on {args.device}", flush=True)

    out_root = Path(args.out)
    n_ok = n_skip = n_err = 0
    t0 = time.time()
    for i, r in enumerate(rows):
        vid = r["video_id"]
        vdir = out_root / vid
        if (vdir / "features.npy").exists():
            n_skip += 1
            continue
        pngs = sorted((Path(args.frames_base) / vid / "frames").glob("*.png"),
                      key=lambda p: p.stem)[: args.max_frames]
        if not pngs:
            n_err += 1
            continue
        try:
            fex = detector.detect_image([str(p) for p in pngs], batch_size=32)
            mat, au_mat, cols = per_frame_matrix(fex, GROUPS)
            seq = resample_time(mat, args.seq_len)
            au_seq = resample_time(au_mat, args.seq_len)
            if seq is None or au_seq is None:
                raise RuntimeError("no detected faces")
            vdir.mkdir(parents=True, exist_ok=True)
            np.save(vdir / "features.npy", seq.astype(np.float32))
            np.save(vdir / "au_sequence.npy", au_seq.astype(np.float32))
            (vdir / "meta.json").write_text(json.dumps({
                "video_id": vid, "label": int(r["label"]), "source": args.source,
                "n_detected_frames": int(mat.shape[0]), "feat_shape": list(seq.shape),
                "feat_columns": cols}))
            n_ok += 1
        except Exception as e:
            n_err += 1
            print(f"  [err] {vid}: {str(e)[:90]}", flush=True)
        if (i + 1) % 20 == 0 or i + 1 == len(rows):
            rate = (i + 1) / max(time.time() - t0, 1e-6)
            print(f"[seq-feat] {i+1}/{len(rows)} ok={n_ok} skip={n_skip} err={n_err} "
                  f"({rate:.2f}/s)", flush=True)
    print(f"\n완료: ok={n_ok} skip={n_skip} err={n_err}")


if __name__ == "__main__":
    main()
