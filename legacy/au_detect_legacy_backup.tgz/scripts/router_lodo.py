#!/usr/bin/env python
"""Leave-one-domain-out: 라우터가 '한 번도 안 본 도메인'에 일반화되나?

in-the-wild = 영구 OOD. 라우터의 pooled-CV 0.837이 진짜 일반화인지 2도메인 암기인지
가르는 유일한 방법 = 한 도메인만 보고 학습 -> 다른 도메인(미지)에서 평가.

캐시(convnext_stage/router_cache.npz) 재사용. OOD ref=CelebDF val(고정, ConvNeXt in-dist).
캘리브레이션은 학습 도메인에서만 적합(누수 차단).
"""
import numpy as np
from pathlib import Path

CACHE = "convnext_stage/router_cache.npz"
z = np.load(CACHE, allow_pickle=True)
D = {k: list(z[k]) for k in z.files}
ct, cv, ft = D["celeb_test"], D["celeb_val"], D["ffpp_test"]


def roc_auc(y, s):
    y = np.asarray(y); s = np.asarray(s)
    np_, nn = (y == 1).sum(), (y == 0).sum()
    if np_ == 0 or nn == 0:
        return float("nan")
    r = np.argsort(np.argsort(s)) + 1
    return float((r[y == 1].sum() - np_ * (np_ + 1) / 2) / (np_ * nn))


def A(b, k):
    return np.array([r[k] for r in b])


def F(b):
    return np.stack([r["feat"] for r in b])


def ood_builder(ref, dim=50):
    mu0, sd0 = ref.mean(0), ref.std(0) + 1e-6
    R = (ref - mu0) / sd0
    _, _, Vt = np.linalg.svd(R, full_matrices=False)
    W = Vt[:dim].T
    P = R @ W
    mu = P.mean(0)
    cov = np.cov(P, rowvar=False) + 1e-3 * np.eye(dim)
    inv = np.linalg.inv(cov)
    def s(feat):
        X = ((feat - mu0) / sd0) @ W - mu
        return np.sqrt(np.einsum("ij,jk,ik->i", X, inv, X))
    return s


ood = ood_builder(F(cv))


def pcal(train_scores):
    rs = np.sort(train_scores)
    return lambda x: np.searchsorted(rs, x, side="right") / len(rs)


def logfit(X, y, iters=3000, lr=0.2, l2=1e-2):
    mu, sd = X.mean(0), X.std(0) + 1e-8
    Xs = (X - mu) / sd
    w = np.zeros(Xs.shape[1]); b = 0.0
    for _ in range(iters):
        p = 1 / (1 + np.exp(-(Xs @ w + b)))
        g = p - y
        w -= lr * (Xs.T @ g / len(y) + l2 * w); b -= lr * g.mean()
    return dict(w=w, b=b, mu=mu, sd=sd)


def logpred(m, X):
    return 1 / (1 + np.exp(-(((X - m["mu"]) / m["sd"]) @ m["w"] + m["b"])))


def fvec(c1, c2, z, zmu, zsd):
    return np.c_[c1, c2, np.abs(c1 - .5), np.abs(c2 - .5), c1 - c2, (z - zmu) / zsd]


def run(train, test, tr_name, te_name):
    p1t, p2t = A(train, "p1"), A(train, "p2")
    p1e, p2e = A(test, "p1"), A(test, "p2")
    yt, ye = A(train, "y"), A(test, "y")
    zt, ze = ood(F(train)), ood(F(test))
    zmu, zsd = zt.mean(), zt.std() + 1e-6           # 학습 도메인 통계로만 정규화

    c1 = pcal(p1t); c2 = pcal(p2t)                  # 캘리브레이션도 학습 도메인만
    Xtr = fvec(c1(p1t), c2(p2t), zt, zmu, zsd)
    Xte = fvec(c1(p1e), c2(p2e), ze, zmu, zsd)
    gate = logfit(Xtr, yt)
    pred = logpred(gate, Xte)

    print(f"\n=== 학습 {tr_name} -> 평가 {te_name}(미지) ===")
    print(f"  ConvNeXt-only(test) AUC = {roc_auc(ye, p1e):.3f}")
    print(f"  AU-only(test)       AUC = {roc_auc(ye, p2e):.3f}")
    print(f"  LODO 메타게이트(test) AUC = {roc_auc(ye, pred):.3f}")
    # 게이트가 어느 쪽으로 기울었나(학습도메인 챔피언 추종 여부)
    w = gate["w"]
    print(f"  gate weights [c1,c2,|c1|,|c2|,c1-c2,ood] = {np.round(w,2)}")
    return roc_auc(ye, pred), max(roc_auc(ye, p1e), roc_auc(ye, p2e))


print("=" * 60)
print("LODO: 라우터가 미지 도메인에 일반화되나?  (pooled-CV 0.837 대조)")
g1, o1 = run(ct, ft, "CelebDF", "FF++")
g2, o2 = run(ft, ct, "FF++", "CelebDF")
print("\n" + "=" * 60)
print(f"미지 도메인 게이트 macro = {0.5*(g1+g2):.3f}   (그 도메인 챔피언 macro = {0.5*(o1+o2):.3f})")
print("→ 게이트가 챔피언에 못 미치면: 라우팅이 '안 본 도메인'엔 일반화 안 됨(=in-the-wild 경고)")
