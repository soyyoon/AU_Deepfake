#!/usr/bin/env python
"""AU 다양성 학습 LODO: 학습 도메인을 늘리면 '안 본 도메인' 성능이 오르나?

XGBoost(30ch stat feature) 재학습은 수초. 각 도메인 hold-out -> 나머지를 1개씩/2개 합쳐
학습 -> hold-out에서 AUC. 다양성(2도메인)이 최고 단일보다 높으면 '다양성이 일반화에 기여'.

도메인 풀: CelebDF(train/test), FFpp(train/test) = splits.csv, WildDeepfake(847, 단일 풀).
"""
import csv
import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from au_detect.features import stat_features            # noqa: E402
from au_detect.metrics import roc_auc                   # noqa: E402


def load_XY(items, data_dir="data"):
    X, y = [], []
    for vid, lab in items:
        f = Path(data_dir) / vid / "features.npy"
        if not f.exists():
            continue
        X.append(stat_features(np.load(f)))
        y.append(int(lab))
    return np.stack(X), np.array(y)


def train_eval(train_items, test_XY):
    import xgboost as xgb
    Xtr, ytr = load_XY(train_items)
    npos, nneg = (ytr == 1).sum(), (ytr == 0).sum()
    clf = xgb.XGBClassifier(n_estimators=300, max_depth=4, learning_rate=0.1,
                            subsample=0.9, colsample_bytree=0.9, eval_metric="auc",
                            scale_pos_weight=nneg / max(npos, 1), n_jobs=8, verbosity=0)
    clf.fit(Xtr, ytr)
    Xte, yte = test_XY
    return roc_auc(yte, clf.predict_proba(Xte)[:, 1]), len(ytr)


# 도메인 풀 구성
rows = list(csv.DictReader(open("outputs/v2/splits.csv")))
def pool(src, split):
    return [(r["video_id"], int(r["label"])) for r in rows
            if r["source"] == src and r["split"] == split]

wdf = [(r["video_id"], int(r["label"]))
       for r in csv.DictReader(open("convnext_stage/wdf_targets.csv"))]

TRAIN = {"CelebDF": pool("CelebDF", "train"), "FF++": pool("FFpp", "train"), "WildDeepfake": wdf}
TEST = {"CelebDF": pool("CelebDF", "test"), "FF++": pool("FFpp", "test"), "WildDeepfake": wdf}
domains = ["CelebDF", "FF++", "WildDeepfake"]

# 테스트셋 feature 미리 로드
TEST_XY = {d: load_XY(TEST[d]) for d in domains}

print("=" * 70)
print("AU 다양성 LODO: hold-out 도메인 성능 (학습 도메인 조합별)")
print("=" * 70)
for held in domains:
    others = [d for d in domains if d != held]
    print(f"\n■ hold-out = {held}  (test n={len(TEST_XY[held][1])})")
    singles = {}
    for d in others:
        auc, n = train_eval(TRAIN[d], TEST_XY[held])
        singles[d] = auc
        print(f"    학습[{d:12s}] (n={n:4d}) -> {held} AUC = {auc:.3f}")
    # 2도메인(다양성)
    combo = TRAIN[others[0]] + TRAIN[others[1]]
    auc2, n2 = train_eval(combo, TEST_XY[held])
    best_single = max(singles.values())
    delta = auc2 - best_single
    mark = "▲다양성이득" if delta > 0.005 else ("▼손해" if delta < -0.005 else "=중립")
    print(f"    학습[{others[0]}+{others[1]}] (n={n2:4d}) -> {held} AUC = {auc2:.3f}  "
          f"(최고단일 {best_single:.3f}, {mark}{delta:+.3f})")

print("\n(다양성 2도메인 학습이 최고 단일보다 높으면 = 다양성이 미지도메인 일반화에 기여)")
