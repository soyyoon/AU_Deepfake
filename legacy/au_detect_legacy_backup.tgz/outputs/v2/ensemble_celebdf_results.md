# AU × ConvNeXt 앙상블 — CelebDF 공정 비교 실측 결과

공통 평가셋: AU identity-disjoint **CelebDF test** 204개(fake 113 / real 91).
ConvNeXt: `epoch17_selauc0.9142.pt` 로컬 GPU 추론(419개, cuDNN 끔).
join: video_id canonical key, label 불일치 0, 매칭 204/204.

## 단일 모델 (같은 공통셋)
| | 전체 n=204 | heldout n=92 | trained n=112 |
|---|---|---|---|
| ConvNeXt-only | 0.9594 | **0.9223** | 0.9862 |
| AU-only | 0.5871 | 0.5860 | 0.5844 |

→ ConvNeXt가 자기 train에서 본 112개(0.9862) vs 진짜 held-out 92개(**0.9223**). 누수 인플레 확인.
정직한 ConvNeXt 성능 = **0.922**. AU는 CelebDF에서 거의 랜덤(0.587).

## Fusion (단일 최고 0.9594 대비)
| fusion | AUC | Δ |
|---|---|---|
| mean(0.5/0.5) | 0.9327 | ▼ −0.027 |
| weighted (val-fit → **w_cn=1.00**) | 0.9594 | = (AU 완전 무시) |
| LR-stacker | 0.9316 | ▼ −0.028 |
| cascade(margin=0.15) | 0.9594 | = (AU 재판정 **0.0%**) |

## 상보성
corr(p1,p2)=+0.142, 불일치율 45.6%. ConvNeXt틀림&AU맞음=7, AU틀림&ConvNeXt맞음=86.

## 결론
**CelebDF(in-distribution)에서 앙상블은 이득이 없다.**
- val로 최적화한 선형 가중이 **w_cn=1.0** (AU 완전 배제)을 선택.
- cascade는 ConvNeXt가 전 영상에서 confident해 AU를 **한 번도** 호출 안 함(0%).
- mean/LR은 오히려 −0.027~−0.028 하락(AU 노이즈 주입).
- 상보 케이스(ConvNeXt틀림&AU맞음)는 7개뿐 — AU가 near-chance라 이마저 우연 수준.

**단, 주의:** 이 테스트는 AU의 **최약 축(CelebDF 0.587)**에서 이뤄졌다. AU가 상대적으로 강한 곳은 FF++(0.754)·미지 기법(0.72)인데, ConvNeXt 전처리 데이터에 FF++가 없어 그 축에선 앙상블 평가 자체가 불가(공통 영상 없음). AU가 값어치를 할 유일한 시나리오 = ConvNeXt가 무너지는 미지 도메인/기법 — CelebDF는 그 반대(아티팩트 뚜렷)라 애초에 AU가 낄 여지가 없었다.

**실무 함의:** AU를 ConvNeXt 보조로 붙이는 건 CelebDF류 in-distribution에선 무의미. AU는 도메인/기법이 바뀌어 아티팩트 탐지가 실패하는 상황의 보험으로만 의미가 있고, 그건 도메인 다양성 데이터 작업( [[generalization-axes]] )과 함께 별도 축에서 검증해야 함.
