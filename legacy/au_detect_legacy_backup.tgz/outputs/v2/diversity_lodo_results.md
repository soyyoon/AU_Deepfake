# AU 다양성 학습 LODO — 다양성이 미지 도메인 성능을 올리나? (답: 아니오)

XGBoost(30ch) 재학습. 각 도메인 hold-out, 나머지를 1개씩/2개 합쳐 학습 -> hold-out AUC.

| hold-out(미지) | 단일 A | 단일 B | 2도메인(다양성) | Δ vs 최고단일 |
|---|---|---|---|---|
| CelebDF | FF++ 0.546 | WDF 0.560 | FF+++WDF **0.505** | ▼ −0.055 |
| FF++ | CelebDF 0.621 | WDF 0.490 | CelebDF+WDF **0.584** | ▼ −0.037 |
| WildDeepfake | CelebDF 0.530 | FF++ 0.470 | CelebDF+FF++ **0.449** | ▼ −0.081 |

## 결론
1. **AU에선 다양성 학습이 오히려 해롭다** (3/3에서 2도메인 < 최고단일).
2. 애초에 **단일 cross-domain 전이부터 거의 랜덤**(0.47~0.62). AU 표현이 도메인 전이 가능한
   딥페이크 신호를 거의 안 담음 → 도메인을 섞으면 상충 신호로 더 혼란.
3. **병목은 데이터가 아니라 AU 표현 자체**(기존 진단 재확인). 저차원(210d) stat feature는
   서로 다른 도메인의 fake 지문을 화해시키지 못함.

## 함의
- **AU는 야생 배치에 근본적으로 부적합** — 더 다양한 데이터로도 못 고침(표현이 천장).
- "다양성 학습" 가설의 진짜 시험대 = **고용량 모델(ConvNeXt)** 재학습. 딥모델은 다양한
  데이터에서 도메인 불변 표현을 학습할 capacity가 있음(문헌상 diversity가 딥 검출기 일반화에
  기여). 단 비용 큼(DFD+CelebDF 프레임 ~60GB 재다운 + 수시간 GPU 학습).
- 대안(중간 비용): ConvNeXt penultimate feature를 다양한 도메인에서 뽑아 **head만 재학습**
  (linear probe) -> frozen 아티팩트 표현이 다양성으로 전이 가능한지 싸게 확인.

관련: [[diagnosis-data-not-model]] [[generalization-axes]] [[ensemble-fair-comparison]]
