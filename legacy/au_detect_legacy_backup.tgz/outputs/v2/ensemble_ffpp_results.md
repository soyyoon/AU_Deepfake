# AU × ConvNeXt 앙상블 — FF++ 진단 (ConvNeXt OOD)

현 ConvNeXt(`epoch17`, DFD+CelebDF 학습)를 **FF++ test 200개**(real 100 + 미지 기법 5종 각 20)에 추론.
FF++ 프레임은 ConvNeXt의 DFD 크롭 전략(largest_face_square_bbox, margin 0.35) 복제로 로컬 생성.
FF++ test에 ConvNeXt 학습기법(DeepFakeDetection)은 0개 → **완전 OOD**.

## 단일 모델 (공통 test 200, real 100 / fake 100)
| | AUC |
|---|---|
| ConvNeXt-only | **0.531** (거의 랜덤 — 붕괴) |
| AU-only | **0.754** |

→ CelebDF의 **거울상**(거기선 ConvNeXt 0.92 / AU 0.59).

## 기법별 (reals + 해당 기법 fakes)
| 기법 | ConvNeXt | AU | 승자 |
|---|---|---|---|
| Deepfakes | 0.853 | 0.889 | 비등 |
| Face2Face | 0.510 | **0.913** | AU 압승 |
| FaceShifter | 0.411 | 0.643 | AU |
| FaceSwap | **0.337** | 0.532 | 둘 다 약(ConvNeXt 역상관) |
| NeuralTextures | 0.545 | **0.791** | AU |

**핵심:** ConvNeXt는 학습과 유사한 **Deepfakes(오토인코더 블렌딩)만 전이(0.85)**, 나머지 4기법은 랜덤~역상관. 특히 **reenactment(Face2Face/NeuralTextures)엔 완전 무력(0.51/0.55)**. AU는 바로 그 reenactment에 강함(0.91/0.79) — 표정 동역학 단서.

## 크롭 검증(내부)
같은 크롭 파이프라인으로 ConvNeXt가 Deepfakes에서 0.853을 냄 → **크롭은 충실**(망가졌으면 어떤 기법도 못 맞힘). 즉 나머지 붕괴는 크롭 아티팩트가 아니라 **진짜 기법 일반화 실패**.

## 확률 붕괴 양상
ConvNeXt p1: real 0.019 / fake 0.115 (전부 "real"로 판정, fake 신호 못 잡음).

## Fusion
- mean = 0.754(=AU). cascade(margin 0.15) = **0.531** — ConvNeXt가 전 영상 confident해 AU 재판정 0% → **confidently wrong**을 그대로 신뢰(최악 실패). CelebDF와 동일한 게이팅 결함이 여기선 치명적.
- weighted/LR은 FFpp val ConvNeXt 확률 미생성으로 생략(필요시 val 크롭+추론 ~20분).

## 결론 (원 질문에 대한 답)
**AU와 아티팩트 모델은 강하게 상보적 — 단, "단순 보조 앙상블"로는 못 잡는다.**
- 둘은 **도메인·기법에 따라 정반대로** 실패(CelebDF↔FF++, 블렌딩↔reenactment).
- 정적 가중(CelebDF에선 w_cn=1.0, FF++에선 w_cn≈0)·confidence 게이팅 모두 한쪽에서 붕괴. ConvNeXt가 OOD에서 **confidently wrong**이라 게이팅이 특히 위험.
- 상보성의 상한(기법별 best)은 크지만, 그걸 실현하려면 **OOD/도메인 인지 라우터**(언제 어느 모델을 믿을지)가 필요. 단순 score fusion 아님.

**다음 후보:** (1) OOD 감지 라우터/메타학습(도메인 특징으로 게이팅), (2) ConvNeXt를 FF++ 포함 재학습해 아티팩트 측 일반화 자체를 넓힘(그러면 앙상블 불필요해질 수도), (3) 미지 도메인(DFDC)에서 3자(ConvNeXt/AU/앙상블) 재확인. 관련: [[generalization-axes]] [[ensemble-fair-comparison]]
